'use server'

export interface SNPData {
  rsId: string
  chromosome: string
  position: string
  genes: string[]
  phenotypes: string[]
  clinicalSignificance: string
  variantType: string
}

// Helper function to add delay between requests
const delay = (ms: number) => new Promise(resolve => setTimeout(resolve, ms))

// Helper function to chunk array into smaller pieces
function chunkArray<T>(array: T[], size: number): T[][] {
  const chunks: T[][] = []
  for (let i = 0; i < array.length; i += size) {
    chunks.push(array.slice(i, i + size))
  }
  return chunks
}

// Helper function to determine variant type
function determineVariantType(snp: any): string {
  const fxnClass = snp.fxn_class?.toLowerCase() || ''

  if (fxnClass.includes('missense')) return 'missense'
  if (fxnClass.includes('synonymous')) return 'synonymous'
  if (fxnClass.includes('nonsense')) return 'nonsense'
  if (fxnClass.includes('frameshift')) return 'frameshift'
  if (fxnClass.includes('splice')) return 'splice-site'
  if (fxnClass.includes('intron')) return 'intronic'
  if (fxnClass.includes('utr')) return 'UTR'
  if (fxnClass.includes('upstream') || fxnClass.includes('downstream')) return 'regulatory'

  return 'other'
}

// Helper function to format phenotype search query
function formatPhenotypeQuery(phenotype: string): string {
  return `${phenotype}[phenotype] OR "${phenotype}"[trait]`
}

export async function fetchSNPsByQuery(
  query: string,
  page: number = 1,
  limit: number = 10,
  searchType: 'general' | 'phenotype' = 'general'
): Promise<{
  snps: SNPData[]
  total: number
  error?: string
}> {
  try {
    const formattedQuery = searchType === 'phenotype' ? formatPhenotypeQuery(query) : query
    const searchUrl = `https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esearch.fcgi?db=snp&term=${formattedQuery}&retstart=${(page - 1) * limit}&retmax=${limit}&retmode=json`
    const searchResponse = await fetch(searchUrl)
    if (!searchResponse.ok) throw new Error('Failed to fetch SNP IDs')
    const searchData = await searchResponse.json()

    if (!searchData.esearchresult.idlist || searchData.esearchresult.idlist.length === 0) {
      return {
        snps: [],
        total: 0,
        error: 'No SNPs found matching your query'
      }
    }

    const snpIds = searchData.esearchresult.idlist
    const snps: SNPData[] = []

    const summaryUrl = `https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esummary.fcgi?db=snp&id=${snpIds.join(',')}&retmode=json`
    const summaryResponse = await fetch(summaryUrl)
    if (!summaryResponse.ok) throw new Error('Failed to fetch SNP details')
    const summaryData = await summaryResponse.json()

    for (const snpId of snpIds) {
      const snp = summaryData.result[snpId]
      if (snp) {
        snps.push({
          rsId: `rs${snpId}`,
          chromosome: snp.chr || 'N/A',
          position: snp.chrpos || 'N/A',
          genes: snp.genes ? snp.genes.map((gene: any) => typeof gene === 'object' ? gene.name : gene) : [],
          phenotypes: snp.phenotypes || [],
          clinicalSignificance: snp.clinical_significance || 'Not provided',
          variantType: determineVariantType(snp)
        })
      }
    }

    return {
      snps,
      total: parseInt(searchData.esearchresult.count)
    }

  } catch (error) {
    return {
      snps: [],
      total: 0,
      error: 'An error occurred while fetching SNP data'
    }
  }
}

export async function fetchAllSNPs(
  query: string,
  onProgress?: (progress: number) => void
): Promise<{
  snps: SNPData[]
  error?: string
}> {
  try {
    // First get total count with a smaller timeout
    const controller = new AbortController()
    const timeoutId = setTimeout(() => controller.abort(), 10000) // 10 second timeout

    const searchUrl = `https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esearch.fcgi?db=snp&term=${query}&retmax=0&retmode=json`
    const searchResponse = await fetch(searchUrl, { signal: controller.signal })
    clearTimeout(timeoutId)
    
    if (!searchResponse.ok) throw new Error('Failed to fetch total count')
    const searchData = await searchResponse.json()
    
    const total = parseInt(searchData.esearchresult.count)
    if (total === 0) {
      return {
        snps: [],
        error: 'No SNPs found matching your query'
      }
    }

    // Limit total results to 10000 to prevent timeouts
    const maxResults = Math.min(total, 10000)
    const batchSize = 100 // Reduced batch size for better reliability
    const batches = Math.ceil(maxResults / batchSize)
    const allSnps: SNPData[] = []

    for (let i = 0; i < batches; i++) {
      try {
        // Fetch batch of SNP IDs
        const batchSearchUrl = `https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esearch.fcgi?db=snp&term=${query}&retstart=${i * batchSize}&retmax=${batchSize}&retmode=json`
        const batchSearchResponse = await fetch(batchSearchUrl)
        if (!batchSearchResponse.ok) throw new Error('Failed to fetch batch of SNP IDs')
        const batchSearchData = await batchSearchResponse.json()
        
        if (batchSearchData.esearchresult.idlist && batchSearchData.esearchresult.idlist.length > 0) {
          // Split IDs into smaller chunks for summary requests
          const idChunks = chunkArray(batchSearchData.esearchresult.idlist, 50)
          
          for (const chunk of idChunks) {
            // Fetch details for this chunk
            const summaryUrl = `https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esummary.fcgi?db=snp&id=${chunk.join(',')}&retmode=json`
            const summaryResponse = await fetch(summaryUrl)
            if (!summaryResponse.ok) throw new Error('Failed to fetch SNP details')
            const summaryData = await summaryResponse.json()

            for (const snpId of chunk) {
              const snp = summaryData.result[snpId]
              if (snp) {
                allSnps.push({
                  rsId: `rs${snpId}`,
                  chromosome: snp.chr || 'N/A',
                  position: snp.chrpos || 'N/A',
                  genes: snp.genes ? snp.genes.map((gene: any) => typeof gene === 'object' ? gene.name : gene) : [],
                  phenotypes: snp.phenotypes || [],
                  clinicalSignificance: snp.clinical_significance || 'Not provided',
                  variantType: determineVariantType(snp)
                })
              }
            }

            // Add a small delay between chunk requests
            await delay(334) // ~3 requests per second
          }
        }

        // Update progress
        if (onProgress) {
          onProgress(Math.round((i + 1) / batches * 100))
        }

      } catch (error) {
        console.error(`Error in batch ${i}:`, error)
        // Continue with next batch instead of failing completely
        continue
      }

      // Add a delay between batches
      await delay(1000)
    }

    if (allSnps.length === 0) {
      return {
        snps: [],
        error: 'Failed to fetch SNP data. Please try again.'
      }
    }

    return { snps: allSnps }

  } catch (error) {
    return {
      snps: [],
      error: error instanceof Error ? error.message : 'An error occurred while fetching SNP data'
    }
  }
}

export async function fetchAllSNPIds(
  query: string,
  variantTypeFilter?: string[],
  onProgress?: (progress: number) => void
): Promise<{
  rsIds: string[]
  error?: string
}> {
  try {
    const searchUrl = `https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esearch.fcgi?db=snp&term=${query}&retmax=100000&retmode=json`
    const searchResponse = await fetch(searchUrl)
    if (!searchResponse.ok) throw new Error('Failed to fetch SNP IDs')
    const searchData = await searchResponse.json()
    
    if (!searchData.esearchresult.idlist || searchData.esearchresult.idlist.length === 0) {
      return { rsIds: [], error: 'No SNPs found matching your query' }
    }

    // If no variant type filter is applied, return all IDs
    if (!variantTypeFilter || variantTypeFilter.length === 0) {
      const rsIds = searchData.esearchresult.idlist.map((id: string) => `rs${id}`)
      return { rsIds }
    }

    // If variant type filter is applied, fetch details and filter
    const idChunks = chunkArray(searchData.esearchresult.idlist, 100)
    const filteredIds: string[] = []
    let processedChunks = 0

    for (const chunk of idChunks) {
      const summaryUrl = `https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esummary.fcgi?db=snp&id=${chunk.join(',')}&retmode=json`
      const summaryResponse = await fetch(summaryUrl)
      if (!summaryResponse.ok) throw new Error('Failed to fetch SNP details')
      const summaryData = await summaryResponse.json()

      for (const id of chunk) {
        const snp = summaryData.result[id]
        if (snp && variantTypeFilter.includes(determineVariantType(snp))) {
          filteredIds.push(`rs${id}`)
        }
      }

      processedChunks++
      if (onProgress) {
        onProgress(Math.round((processedChunks / idChunks.length) * 100))
      }

      // Add delay between chunks
      await delay(334)
    }

    return { rsIds: filteredIds }

  } catch (error) {
    return {
      rsIds: [],
      error: error instanceof Error ? error.message : 'An error occurred while fetching SNP IDs'
    }
  }
}

