'use client'

import { useState } from 'react'
import { Search, Loader2, Download, Filter, Database, Tag } from 'lucide-react'
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import {
  Pagination,
  PaginationContent,
  PaginationEllipsis,
  PaginationItem,
  PaginationLink,
  PaginationNext,
  PaginationPrevious,
} from "@/components/ui/pagination"
import { Alert, AlertDescription } from "@/components/ui/alert"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuCheckboxItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
} from "@/components/ui/dropdown-menu"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs"
import { fetchSNPsByQuery, fetchAllSNPIds, type SNPData } from './actions/fetch-snps'

const CLINICAL_SIGNIFICANCE = [
  'pathogenic',
  'likely pathogenic',
  'benign',
  'likely benign',
  'uncertain significance',
  'not provided'
]

const VARIANT_TYPES = [
  'missense',
  'synonymous',
  'nonsense',
  'frameshift',
  'splice-site',
  'intronic',
  'UTR',
  'regulatory',
  'other'
]

export default function SNPExplorer() {
  const [query, setQuery] = useState('')
  const [searchType, setSearchType] = useState<'general' | 'phenotype'>('general')
  const [loading, setLoading] = useState(false)
  const [downloading, setDownloading] = useState(false)
  const [downloadProgress, setDownloadProgress] = useState(0)
  const [error, setError] = useState<string | null>(null)
  const [snps, setSnps] = useState<SNPData[]>([])
  const [currentPage, setCurrentPage] = useState(1)
  const [totalSnps, setTotalSnps] = useState(0)
  const [selectedSignificance, setSelectedSignificance] = useState<string[]>([])
  const [selectedVariantTypes, setSelectedVariantTypes] = useState<string[]>([])
  const [selectedPhenotypes, setSelectedPhenotypes] = useState<string[]>([])

  const filteredSnps = snps.filter(snp => 
    (selectedSignificance.length === 0 || 
     selectedSignificance.some(sig => 
       snp.clinicalSignificance.toLowerCase().includes(sig.toLowerCase())
     )) &&
    (selectedVariantTypes.length === 0 ||
     selectedVariantTypes.includes(snp.variantType)) &&
    (selectedPhenotypes.length === 0 ||
     selectedPhenotypes.some(phenotype =>
       snp.phenotypes.some(p => p.toLowerCase().includes(phenotype.toLowerCase()))
     ))
  )

  const handleSearch = async (page: number = 1) => {
    if (!query) {
      setError('Please enter a search query')
      return
    }

    setLoading(true)
    setError(null)

    try {
      const result = await fetchSNPsByQuery(query, page, 10, searchType)
      
      if (result.error) {
        setError(result.error)
        setSnps([])
      } else {
        setSnps(result.snps)
        setTotalSnps(result.total)
        setCurrentPage(page)
      }
    } catch (err) {
      setError('An error occurred while fetching data')
      setSnps([])
    } finally {
      setLoading(false)
    }
  }

  const handleDownloadAll = async () => {
    setDownloading(true)
    setDownloadProgress(0)
    setError(null)

    try {
      const result = await fetchAllSNPIds(
        query, 
        selectedVariantTypes,
        (progress) => setDownloadProgress(progress)
      )

      if (result.error) {
        setError(result.error)
      } else {
        const csv = ['RS ID', ...result.rsIds].join('\n')

        const blob = new Blob([csv], { type: 'text/csv' })
        const url = URL.createObjectURL(blob)
        const a = document.createElement('a')
        a.href = url
        a.download = `snp-ids-${query}.csv`
        document.body.appendChild(a)
        a.click()
        document.body.removeChild(a)
        URL.revokeObjectURL(url)
      }
    } catch (err) {
      setError('An error occurred while downloading data')
    } finally {
      setDownloading(false)
      setDownloadProgress(0)
    }
  }

  const handleExportCurrent = () => {
    const csv = [
      ['RS ID', 'Chromosome', 'Position', 'Genes', 'Phenotypes', 'Clinical Significance', 'Variant Type'],
      ...filteredSnps.map(snp => [
        snp.rsId,
        snp.chromosome,
        snp.position,
        snp.genes.join(';'),
        snp.phenotypes.join(';'),
        snp.clinicalSignificance,
        snp.variantType
      ])
    ].map(row => row.join(',')).join('\n')

    const blob = new Blob([csv], { type: 'text/csv' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = `current-snp-results-${query}.csv`
    document.body.appendChild(a)
    a.click()
    document.body.removeChild(a)
    URL.revokeObjectURL(url)
  }

  const totalPages = Math.ceil(totalSnps / 10)

  const uniquePhenotypes = Array.from(
    new Set(
      snps.flatMap(snp => snp.phenotypes)
        .filter(Boolean)
    )
  )

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="ncbi-gradient text-white">
        <div className="container mx-auto py-6 px-4">
          <div className="flex items-center gap-3 mb-4">
            <Database className="h-8 w-8" />
            <h1 className="text-3xl font-bold tracking-tight">NCBI dbSNP Explorer</h1>
          </div>
          <p className="text-blue-100 max-w-2xl">
            Search for SNPs using RS IDs, gene symbols, chromosomal locations, or phenotypes. 
            Access comprehensive information about genetic variations from the NCBI database.
          </p>
        </div>
      </header>

      <main className="container mx-auto py-8 px-4">
        <div className="space-y-6">
          <div className="ncbi-card rounded-lg p-6">
            <Tabs defaultValue="general" className="w-full" onValueChange={(value) => setSearchType(value as 'general' | 'phenotype')}>
              <TabsList className="mb-4">
                <TabsTrigger value="general">General Search</TabsTrigger>
                <TabsTrigger value="phenotype">Search by Phenotype</TabsTrigger>
              </TabsList>
              <TabsContent value="general">
                <div className="flex gap-2">
                  <Input
                    placeholder="Enter RS ID, gene symbol, or chromosomal location (e.g., rs1234, BRCA1, chr7:140453136)..."
                    value={query}
                    onChange={(e) => setQuery(e.target.value)}
                    className="max-w-xl"
                  />
                  <Button 
                    onClick={() => handleSearch(1)}
                    disabled={loading || downloading}
                    className="bg-blue-800 hover:bg-blue-900"
                  >
                    {loading ? (
                      <Loader2 className="h-4 w-4 animate-spin" />
                    ) : (
                      <Search className="h-4 w-4" />
                    )}
                    <span className="ml-2">Search</span>
                  </Button>
                </div>
              </TabsContent>
              <TabsContent value="phenotype">
                <div className="flex gap-2">
                  <Input
                    placeholder="Enter phenotype or trait (e.g., diabetes, height, blood pressure)..."
                    value={query}
                    onChange={(e) => setQuery(e.target.value)}
                    className="max-w-xl"
                  />
                  <Button 
                    onClick={() => handleSearch(1)}
                    disabled={loading || downloading}
                    className="bg-blue-800 hover:bg-blue-900"
                  >
                    {loading ? (
                      <Loader2 className="h-4 w-4 animate-spin" />
                    ) : (
                      <Search className="h-4 w-4" />
                    )}
                    <span className="ml-2">Search</span>
                  </Button>
                </div>
              </TabsContent>
            </Tabs>
          </div>

          {error && (
            <Alert variant="destructive">
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          )}

          {totalSnps > 0 && (
            <div className="space-y-4">
              <div className="ncbi-card rounded-lg p-6">
                <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
                  <div className="space-y-1">
                    <h2 className="text-lg font-semibold text-blue-900">Search Results</h2>
                    <p className="text-sm text-gray-600">
                      Found <span className="font-medium">{totalSnps.toLocaleString()}</span> SNPs matching your query
                    </p>
                    {(selectedSignificance.length > 0 || selectedVariantTypes.length > 0 || selectedPhenotypes.length > 0) && (
                      <p className="text-sm text-gray-600">
                        Filtered results: <span className="font-medium">{filteredSnps.length.toLocaleString()}</span> SNPs
                        {' '}({[
                          selectedSignificance.length > 0 && `${selectedSignificance.length} significance filters`,
                          selectedVariantTypes.length > 0 && `${selectedVariantTypes.length} type filters`,
                          selectedPhenotypes.length > 0 && `${selectedPhenotypes.length} phenotype filters`
                        ].filter(Boolean).join(', ')})
                      </p>
                    )}
                  </div>
                  <div className="flex flex-wrap gap-2">
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="outline" className="border-blue-200">
                          <Filter className="h-4 w-4 mr-2" />
                          Filter by Significance
                          {selectedSignificance.length > 0 && (
                            <Badge variant="secondary" className="ml-2 bg-blue-100">
                              {selectedSignificance.length}
                            </Badge>
                          )}
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent className="w-56">
                        <DropdownMenuLabel>Clinical Significance</DropdownMenuLabel>
                        <DropdownMenuSeparator />
                        {CLINICAL_SIGNIFICANCE.map((significance) => (
                          <DropdownMenuCheckboxItem
                            key={significance}
                            checked={selectedSignificance.includes(significance)}
                            onCheckedChange={(checked) => {
                              setSelectedSignificance(
                                checked
                                  ? [...selectedSignificance, significance]
                                  : selectedSignificance.filter((s) => s !== significance)
                              )
                            }}
                          >
                            {significance.charAt(0).toUpperCase() + significance.slice(1)}
                          </DropdownMenuCheckboxItem>
                        ))}
                      </DropdownMenuContent>
                    </DropdownMenu>

                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="outline" className="border-blue-200">
                          <Filter className="h-4 w-4 mr-2" />
                          Filter by Type
                          {selectedVariantTypes.length > 0 && (
                            <Badge variant="secondary" className="ml-2 bg-blue-100">
                              {selectedVariantTypes.length}
                            </Badge>
                          )}
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent className="w-56">
                        <DropdownMenuLabel>Variant Type</DropdownMenuLabel>
                        <DropdownMenuSeparator />
                        {VARIANT_TYPES.map((type) => (
                          <DropdownMenuCheckboxItem
                            key={type}
                            checked={selectedVariantTypes.includes(type)}
                            onCheckedChange={(checked) => {
                              setSelectedVariantTypes(
                                checked
                                  ? [...selectedVariantTypes, type]
                                  : selectedVariantTypes.filter((t) => t !== type)
                              )
                            }}
                          >
                            {type.charAt(0).toUpperCase() + type.slice(1)}
                          </DropdownMenuCheckboxItem>
                        ))}
                      </DropdownMenuContent>
                    </DropdownMenu>

                    {uniquePhenotypes.length > 0 && (
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="outline" className="border-blue-200">
                            <Tag className="h-4 w-4 mr-2" />
                            Filter by Phenotype
                            {selectedPhenotypes.length > 0 && (
                              <Badge variant="secondary" className="ml-2 bg-blue-100">
                                {selectedPhenotypes.length}
                              </Badge>
                            )}
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent className="w-56">
                          <DropdownMenuLabel>Phenotypes</DropdownMenuLabel>
                          <DropdownMenuSeparator />
                          {uniquePhenotypes.map((phenotype) => (
                            <DropdownMenuCheckboxItem
                              key={phenotype}
                              checked={selectedPhenotypes.includes(phenotype)}
                              onCheckedChange={(checked) => {
                                setSelectedPhenotypes(
                                  checked
                                    ? [...selectedPhenotypes, phenotype]
                                    : selectedPhenotypes.filter((p) => p !== phenotype)
                                )
                              }}
                            >
                              {phenotype}
                            </DropdownMenuCheckboxItem>
                          ))}
                        </DropdownMenuContent>
                      </DropdownMenu>
                    )}

                    <Button
                      variant="outline"
                      onClick={handleExportCurrent}
                      disabled={downloading}
                      className="border-blue-200"
                    >
                      <Download className="h-4 w-4 mr-2" />
                      Export Current Page
                    </Button>
                    <Button
                      onClick={handleDownloadAll}
                      disabled={downloading}
                      className="bg-blue-800 hover:bg-blue-900"
                    >
                      {downloading ? (
                        <Loader2 className="h-4 w-4 animate-spin mr-2" />
                      ) : (
                        <Download className="h-4 w-4 mr-2" />
                      )}
                      Download RS IDs
                    </Button>
                  </div>
                </div>

                {downloading && (
                  <div className="mt-4 space-y-2">
                    <div className="flex items-center justify-between text-sm text-gray-600">
                      <span>Downloading SNPs...</span>
                      <span>{downloadProgress}%</span>
                    </div>
                    <Progress value={downloadProgress} className="bg-blue-100" />
                  </div>
                )}
              </div>

              <div className="ncbi-card rounded-lg overflow-hidden">
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow className="bg-blue-50">
                        <TableHead className="font-semibold text-blue-900">RS ID</TableHead>
                        <TableHead className="font-semibold text-blue-900">Location</TableHead>
                        <TableHead className="font-semibold text-blue-900">Genes</TableHead>
                        <TableHead className="font-semibold text-blue-900">Phenotypes</TableHead>
                        <TableHead className="font-semibold text-blue-900">Clinical Significance</TableHead>
                        <TableHead className="font-semibold text-blue-900">Variant Type</TableHead>
                        <TableHead className="font-semibold text-blue-900">Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {filteredSnps.map((snp) => (
                        <TableRow key={snp.rsId} className="hover:bg-blue-50/50">
                          <TableCell className="font-medium text-blue-800">{snp.rsId}</TableCell>
                          <TableCell>
                            Chr{snp.chromosome}:{snp.position}
                          </TableCell>
                          <TableCell>
                            <div className="flex flex-wrap gap-1">
                              {snp.genes.map((gene: string, i: number) => (
                                <Badge key={i} variant="secondary" className="bg-blue-100 text-blue-800 hover:bg-blue-200">
                                  {typeof gene === 'object' ? gene.name : gene}
                                </Badge>
                              ))}
                            </div>
                          </TableCell>
                          <TableCell>
                            <div className="flex flex-wrap gap-1">
                              {snp.phenotypes.map((phenotype, i) => (
                                <Badge key={i} variant="outline" className="border-purple-200 text-purple-800 bg-purple-50">
                                  {phenotype}
                                </Badge>
                              ))}
                            </div>
                          </TableCell>
                          <TableCell>
                            <Badge 
                              variant={
                                snp.clinicalSignificance.toLowerCase().includes('pathogenic') 
                                  ? 'destructive' 
                                  : snp.clinicalSignificance.toLowerCase().includes('benign')
                                  ? 'secondary'
                                  : 'outline'
                              }
                              className={
                                snp.clinicalSignificance.toLowerCase().includes('pathogenic')
                                  ? 'bg-red-100 text-red-800 hover:bg-red-200'
                                  : snp.clinicalSignificance.toLowerCase().includes('benign')
                                  ? 'bg-green-100 text-green-800 hover:bg-green-200'
                                  : 'bg-gray-100 text-gray-800 hover:bg-gray-200'
                              }
                            >
                              {snp.clinicalSignificance}
                            </Badge>
                          </TableCell>
                          <TableCell>
                            <Badge variant="outline" className="border-blue-200 text-blue-800">
                              {snp.variantType.charAt(0).toUpperCase() + snp.variantType.slice(1)}
                            </Badge>
                          </TableCell>
                          <TableCell>
                            <DropdownMenu>
                              <DropdownMenuTrigger asChild>
                                <Button variant="ghost" size="sm" className="text-blue-800 hover:text-blue-900 hover:bg-blue-50">
                                  <Filter className="h-4 w-4" />
                                </Button>
                              </DropdownMenuTrigger>
                              <DropdownMenuContent align="end">
                                <DropdownMenuItem asChild>
                                  <a
                                    href={`https://www.ncbi.nlm.nih.gov/snp/${snp.rsId}`}
                                    target="_blank"
                                    rel="noopener noreferrer"
                                    className="text-blue-800 hover:text-blue-900"
                                  >
                                    View on dbSNP
                                  </a>
                                </DropdownMenuItem>
                                <DropdownMenuItem asChild>
                                  <a
                                    href={`https://www.ensembl.org/Homo_sapiens/Variation/Explore?v=${snp.rsId}`}
                                    target="_blank"
                                    rel="noopener noreferrer"
                                    className="text-blue-800 hover:text-blue-900"
                                  >
                                    View on Ensembl
                                  </a>
                                </DropdownMenuItem>
                              </DropdownMenuContent>
                            </DropdownMenu>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              </div>

              {totalPages > 1 && (
                <div className="flex justify-center mt-6">
                  <Pagination>
                    <PaginationContent>
                      <PaginationItem>
                        <PaginationPrevious 
                          href="#"
                          onClick={(e) => {
                            e.preventDefault()
                            if (currentPage > 1) {
                              handleSearch(currentPage - 1)
                            }
                          }}
                        />
                      </PaginationItem>
                      
                      {Array.from({ length: Math.min(5, totalPages) }, (_, i) => (
                        <PaginationItem key={i}>
                          <PaginationLink
                            href="#"
                            onClick={(e) => {
                              e.preventDefault()
                              handleSearch(i + 1)
                            }}
                            isActive={currentPage === i + 1}
                            className={currentPage === i + 1 ? 'bg-blue-800 text-white' : ''}
                          >
                            {i + 1}
                          </PaginationLink>
                        </PaginationItem>
                      ))}
                      
                      {totalPages > 5 && (
                        <>
                          <PaginationItem>
                            <PaginationEllipsis />
                          </PaginationItem>
                          <PaginationItem>
                            <PaginationLink
                              href="#"
                              onClick={(e) => {
                                e.preventDefault()
                                handleSearch(totalPages)
                              }}
                            >
                              {totalPages}
                            </PaginationLink>
                          </PaginationItem>
                        </>
                      )}
                      
                      <PaginationItem>
                        <PaginationNext 
                          href="#"
                          onClick={(e) => {
                            e.preventDefault()
                            if (currentPage < totalPages) {
                              handleSearch(currentPage + 1)
                            }
                          }}
                        />
                      </PaginationItem>
                    </PaginationContent>
                  </Pagination>
                </div>
              )}

              <p className="text-sm text-center text-gray-600 mt-4">
                Showing {filteredSnps.length} of {totalSnps} SNPs
                {(selectedSignificance.length > 0 || selectedVariantTypes.length > 0 || selectedPhenotypes.length > 0) && (
                  <> (Filtered by {[
                    selectedSignificance.length > 0 && 'clinical significance',
                    selectedVariantTypes.length > 0 && 'variant type',
                    selectedPhenotypes.length > 0 && 'phenotype'
                  ].filter(Boolean).join(' and ')})</>
                )}
              </p>
            </div>
          )}
        </div>
        <footer className="bg-gray-50 border-t border-gray-200 mt-8">
          <div className="container mx-auto py-8 px-4">
            <div className="text-center text-sm text-gray-600">
              <p className="mb-2">
                Tool developed by{' '}
                <a 
                  href="https://scholar.google.com/citations?user=iqji9O8AAAAJ&hl=en"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-blue-800 hover:text-blue-900 hover:underline"
                >
                  Mohamed Alfaki
                </a>
              </p>
              <p>
                Contact:{' '}
                <a 
                  href="mailto:mohamed.alkhair.alfaki@gmail.com"
                  className="text-blue-800 hover:text-blue-900 hover:underline"
                >
                  mohamed.alkhair.alfaki@gmail.com
                </a>
              </p>
            </div>
          </div>
        </footer>
      </main>
    </div>
  )
}

